# DexDot (com.dexdot.app)

Kotlin + Jetpack Compose Android application providing a persistent floating gesture dot, quick system controls, and a SpeechRecognizer voice assistant.

## Requirements
- Android Studio Ladybug (2024.2+) or newer
- JDK 17
- Android 10+ (API 29+) — verified for Samsung Galaxy A20s (Android 11 / One UI)

## Project Structure
- `app/src/main/AndroidManifest.xml` — Permissions (`SYSTEM_ALERT_WINDOW`, `RECORD_AUDIO`, `FOREGROUND_SERVICE`, `CAMERA`, `WRITE_SETTINGS`), Android 11 `<queries>`, activities, and services.
- `app/src/main/java/com/dexdot/app/MainActivity.kt` — Onboarding & runtime permission launcher + service control hub.
- `app/src/main/java/com/dexdot/app/SettingsActivity.kt` — Dot color, size (`28dp–64dp`), opacity, corner anchor, idle pulse, and haptic settings.
- `app/src/main/java/com/dexdot/app/service/OverlayService.kt` — Foreground `LifecycleService` managing `WindowManager` overlay, `GestureDetector` swipe/tap/long-press gestures, and Quick-Menu overlay.
- `app/src/main/java/com/dexdot/app/service/VoiceAssistantService.kt` — Floating `SpeechRecognizer` overlay with RMS-driven waveform bars and command dispatcher.
- `app/src/main/java/com/dexdot/app/service/DexDotAccessibilityService.kt` — Optional AccessibilityService bridge.
- `app/src/main/java/com/dexdot/app/util/SystemControlHelper.kt` — `AudioManager`, `CameraManager` torch, `Settings.System` brightness, and app launch intents.
- `app/src/main/java/com/dexdot/app/data/DotPreferences.kt` — DataStore preferences persistence.
