package com.dexdot.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dexdot_prefs")

enum class DotCorner(val label: String) {
    BOTTOM_RIGHT("Bottom Right"),
    BOTTOM_LEFT("Bottom Left"),
    TOP_RIGHT("Top Right"),
    TOP_LEFT("Top Left")
}

data class DotConfig(
    val colorArgb: Long = 0xFF38BDF8L,
    val sizeDp: Int = 24,
    val opacity: Float = 0.70f,
    val corner: DotCorner = DotCorner.BOTTOM_RIGHT,
    val customX: Int = -1,
    val customY: Int = -1,
    val pulseEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
    val serviceActive: Boolean = false,
    val onboardingCompleted: Boolean = false
)

/**
 * Reactive DataStore wrapper persisting DexDot appearance, position, and service preferences.
 */
class DotPreferences(private val context: Context) {

    private object Keys {
        val COLOR_ARGB = longPreferencesKey("color_argb")
        val SIZE_DP = intPreferencesKey("size_dp")
        val OPACITY = floatPreferencesKey("opacity")
        val CORNER = intPreferencesKey("corner")
        val CUSTOM_X = intPreferencesKey("custom_x")
        val CUSTOM_Y = intPreferencesKey("custom_y")
        val PULSE_ENABLED = booleanPreferencesKey("pulse_enabled")
        val HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        val SERVICE_ACTIVE = booleanPreferencesKey("service_active")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
    }

    val configFlow: Flow<DotConfig> = context.dataStore.data.map { prefs ->
        val cornerOrdinal = prefs[Keys.CORNER] ?: DotCorner.BOTTOM_RIGHT.ordinal
        DotConfig(
            colorArgb = prefs[Keys.COLOR_ARGB] ?: 0xFF38BDF8L,
            sizeDp = (prefs[Keys.SIZE_DP] ?: 24).coerceIn(16, 32),
            opacity = (prefs[Keys.OPACITY] ?: 0.70f).coerceIn(0.35f, 0.98f),
            corner = DotCorner.entries.getOrElse(cornerOrdinal) { DotCorner.BOTTOM_RIGHT },
            customX = prefs[Keys.CUSTOM_X] ?: -1,
            customY = prefs[Keys.CUSTOM_Y] ?: -1,
            pulseEnabled = prefs[Keys.PULSE_ENABLED] ?: true,
            hapticEnabled = prefs[Keys.HAPTIC_ENABLED] ?: true,
            serviceActive = prefs[Keys.SERVICE_ACTIVE] ?: false,
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false
        )
    }

    suspend fun setColor(colorArgb: Long) {
        context.dataStore.edit { it[Keys.COLOR_ARGB] = colorArgb }
    }

    suspend fun setSizeDp(sizeDp: Int) {
        context.dataStore.edit { it[Keys.SIZE_DP] = sizeDp.coerceIn(16, 32) }
    }

    suspend fun setOpacity(opacity: Float) {
        context.dataStore.edit { it[Keys.OPACITY] = opacity.coerceIn(0.35f, 0.98f) }
    }

    suspend fun setCorner(corner: DotCorner) {
        context.dataStore.edit {
            it[Keys.CORNER] = corner.ordinal
            // Reset manual drag offset so the dot snaps cleanly to the chosen corner
            it[Keys.CUSTOM_X] = -1
            it[Keys.CUSTOM_Y] = -1
        }
    }

    suspend fun setCustomPosition(x: Int, y: Int) {
        context.dataStore.edit {
            it[Keys.CUSTOM_X] = x
            it[Keys.CUSTOM_Y] = y
        }
    }

    suspend fun setPulseEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.PULSE_ENABLED] = enabled }
    }

    suspend fun setHapticEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.HAPTIC_ENABLED] = enabled }
    }

    suspend fun setServiceActive(active: Boolean) {
        context.dataStore.edit { it[Keys.SERVICE_ACTIVE] = active }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }
}
