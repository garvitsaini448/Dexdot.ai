package com.dexdot.app.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Optional AccessibilityService enabling advanced system actions
 * (Back, Home, Recents, Notifications, Screen Lock) on Android 10+.
 */
class DexDotAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Reserved for context-aware gesture triggers per foreground package
    }

    override fun onInterrupt() {
        // Service interrupted by system
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun triggerGlobalAction(action: Int): Boolean {
        return performGlobalAction(action)
    }

    companion object {
        @Volatile
        var instance: DexDotAccessibilityService? = null
            private set
    }
}
