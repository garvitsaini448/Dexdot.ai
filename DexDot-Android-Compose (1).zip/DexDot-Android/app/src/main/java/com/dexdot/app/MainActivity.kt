package com.dexdot.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.dexdot.app.data.DotConfig
import com.dexdot.app.data.DotPreferences
import com.dexdot.app.service.OverlayService
import com.dexdot.app.service.VoiceAssistantService
import com.dexdot.app.ui.onboarding.OnboardingScreen
import com.dexdot.app.ui.onboarding.PermissionStatusState
import com.dexdot.app.ui.theme.DexAccentSky
import com.dexdot.app.ui.theme.DexBgCanvas
import com.dexdot.app.ui.theme.DexBorder
import com.dexdot.app.ui.theme.DexDotTheme
import com.dexdot.app.ui.theme.DexSuccess
import com.dexdot.app.ui.theme.DexSurface
import com.dexdot.app.ui.theme.DexTextPrimary
import com.dexdot.app.ui.theme.DexTextSecondary
import com.dexdot.app.util.SystemControlHelper
import kotlinx.coroutines.launch

/**
 * Entry point for DexDot.
 * Guides first-time users through required permissions on onboarding,
 * then provides a clean control hub for starting/stopping the floating dot.
 */
class MainActivity : ComponentActivity() {

    private lateinit var prefs: DotPreferences

    private var permissionState by mutableStateOf(
        PermissionStatusState(
            hasOverlay = false,
            hasAudio = false,
            hasAccessibility = false
        )
    )

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refreshPermissions() }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refreshPermissions() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = DotPreferences(this)
        refreshPermissions()

        setContent {
            val config by prefs.configFlow.collectAsState(initial = DotConfig())
            DexDotTheme {
                if (!config.onboardingCompleted || !permissionState.hasOverlay) {
                    OnboardingScreen(
                        permissions = permissionState,
                        onRequestOverlay = { requestOverlayPermission() },
                        onRequestAudio = { requestAudioPermission() },
                        onRequestAccessibility = { openAccessibilitySettings() },
                        onLaunchDexDot = {
                            lifecycleScope.launch {
                                prefs.setOnboardingCompleted(true)
                            }
                            startOverlayService()
                        }
                    )
                } else {
                    MainDashboardScreen(
                        config = config,
                        permissions = permissionState,
                        onToggleService = {
                            if (config.serviceActive) stopOverlayService() else startOverlayService()
                        },
                        onOpenAssistant = { startVoiceAssistant() },
                        onOpenSettings = {
                            startActivity(Intent(this, SettingsActivity::class.java))
                        },
                        onOpenPermissions = {
                            lifecycleScope.launch { prefs.setOnboardingCompleted(false) }
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissions()
    }

    private fun refreshPermissions() {
        permissionState = PermissionStatusState(
            hasOverlay = SystemControlHelper.hasOverlayPermission(this),
            hasAudio = SystemControlHelper.hasAudioPermission(this),
            hasAccessibility = SystemControlHelper.isAccessibilityServiceEnabled(this)
        )
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestAudioPermission() {
        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun startOverlayService() {
        if (!SystemControlHelper.hasOverlayPermission(this)) {
            requestOverlayPermission()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !SystemControlHelper.hasNotificationPermission(this)
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val intent = Intent(this, OverlayService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopOverlayService() {
        stopService(Intent(this, OverlayService::class.java))
    }

    private fun startVoiceAssistant() {
        val intent = Intent(this, VoiceAssistantService::class.java).apply {
            action = VoiceAssistantService.ACTION_START_LISTENING
        }
        startService(intent)
    }
}

@Composable
private fun MainDashboardScreen(
    config: DotConfig,
    permissions: PermissionStatusState,
    onToggleService: () -> Unit,
    onOpenAssistant: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPermissions: () -> Unit
) {
    val dotColor = Color(config.colorArgb)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DexBgCanvas)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DexDot",
                    color = DexTextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (config.serviceActive) "Floating dot active on screen" else "Floating dot paused",
                    color = if (config.serviceActive) DexSuccess else DexTextSecondary,
                    fontSize = 13.sp
                )
            }

            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(dotColor.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(dotColor)
                )
            }
        }

        Button(
            onClick = onToggleService,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (config.serviceActive) Color(0xFF1F2937) else DexAccentSky,
                contentColor = if (config.serviceActive) DexTextPrimary else Color(0xFF06131F)
            )
        ) {
            Text(
                text = if (config.serviceActive) "Stop Floating Dot" else "Start Floating Dot",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onOpenAssistant,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, DexBorder)
            ) {
                Icon(Icons.Rounded.Mic, contentDescription = null, tint = DexAccentSky, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Voice Mode", color = DexTextPrimary, fontSize = 13.sp)
            }

            OutlinedButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, DexBorder)
            ) {
                Icon(Icons.Rounded.Settings, contentDescription = null, tint = DexTextPrimary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Customize", color = DexTextPrimary, fontSize = 13.sp)
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = DexSurface,
            border = BorderStroke(1.dp, DexBorder)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Gesture Map",
                    color = DexTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                GestureRow("Swipe Up / Down", "Increase or decrease media volume")
                GestureRow("Swipe Left / Right", "Previous or next media track")
                GestureRow("Single Tap", "Toggle mute / unmute")
                GestureRow("Double Tap", "Launch voice assistant")
                GestureRow("Long Press", "Open quick controls & settings")
                GestureRow("Drag & Release", "Reposition dot anywhere on screen")
            }
        }

        OutlinedButton(
            onClick = onOpenPermissions,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, DexBorder)
        ) {
            val missingCount = listOf(
                permissions.hasOverlay,
                permissions.hasAudio,
                permissions.hasAccessibility
            ).count { !it }
            Text(
                text = if (missingCount == 0) "Review Permissions (All Active)" else "Review Permissions ($missingCount optional/missing)",
                color = DexTextSecondary,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun GestureRow(gesture: String, action: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = gesture, color = DexTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(text = action, color = DexTextSecondary, fontSize = 12.sp)
    }
}
