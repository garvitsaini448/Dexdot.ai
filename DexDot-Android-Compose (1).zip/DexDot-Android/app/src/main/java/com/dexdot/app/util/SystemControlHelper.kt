package com.dexdot.app.util

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.dexdot.app.service.DexDotAccessibilityService

/**
 * Modular hardware & OS helper encapsulating AudioManager, CameraManager,
 * Settings.System brightness, media key dispatch, haptics, and permission queries.
 * Designed for Android 10+ (API 29+), tested for Samsung Galaxy A20s (Android 11).
 */
class SystemControlHelper(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    @Volatile
    var isTorchOn: Boolean = false
        private set

    init {
        registerTorchStateListener()
    }

    private fun registerTorchStateListener() {
        try {
            cameraManager.registerTorchCallback(
                object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                        isTorchOn = enabled
                    }
                },
                null
            )
        } catch (_: Exception) {
            // Device may lack camera flash hardware
        }
    }

    // region Volume & Media Controls

    fun increaseVolume(): Int {
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            AudioManager.ADJUST_RAISE,
            AudioManager.FLAG_SHOW_UI
        )
        return getVolumePercent()
    }

    fun decreaseVolume(): Int {
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return getVolumePercent()
    }

    fun setVolumePercent(percent: Int) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = ((percent.coerceIn(0, 100) / 100f) * max).toInt()
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            target,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun getVolumePercent(): Int {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return ((current.toFloat() / max.toFloat()) * 100f).toInt()
    }

    fun isMuted(): Boolean {
        return audioManager.isStreamMute(AudioManager.STREAM_MUSIC) ||
            audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0
    }

    fun toggleMute(): Boolean {
        val action = if (isMuted()) AudioManager.ADJUST_UNMUTE else AudioManager.ADJUST_MUTE
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            action,
            AudioManager.FLAG_SHOW_UI
        )
        return isMuted()
    }

    fun setMuted(muted: Boolean) {
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (muted) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun nextTrack() {
        dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun previousTrack() {
        dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun dispatchMediaKey(keyCode: Int) {
        val eventTime = SystemClock.uptimeMillis()
        val downEvent = KeyEvent(eventTime, eventTime, KeyEvent.ACTION_DOWN, keyCode, 0)
        val upEvent = KeyEvent(eventTime, eventTime, KeyEvent.ACTION_UP, keyCode, 0)
        audioManager.dispatchMediaKeyEvent(downEvent)
        audioManager.dispatchMediaKeyEvent(upEvent)
    }

    // endregion

    // region Flashlight Controls

    fun toggleFlashlight(): Boolean {
        return setFlashlight(!isTorchOn)
    }

    fun setFlashlight(enabled: Boolean): Boolean {
        return try {
            val cameraId = findFlashCameraId() ?: return false
            cameraManager.setTorchMode(cameraId, enabled)
            isTorchOn = enabled
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun findFlashCameraId(): String? {
        return cameraManager.cameraIdList.firstOrNull { id ->
            val chars = cameraManager.getCameraCharacteristics(id)
            val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            val lensFacing = chars.get(CameraCharacteristics.LENS_FACING)
            hasFlash && lensFacing == CameraCharacteristics.LENS_FACING_BACK
        } ?: cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    }

    // endregion

    // region Brightness Controls

    fun canWriteSystemSettings(): Boolean = Settings.System.canWrite(context)

    fun getBrightnessPercent(): Int {
        return try {
            val raw = Settings.System.getInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                128
            )
            ((raw / 255f) * 100f).toInt().coerceIn(0, 100)
        } catch (_: Exception) {
            50
        }
    }

    fun setBrightnessPercent(percent: Int): Boolean {
        if (!canWriteSystemSettings()) return false
        return try {
            // Switch to manual mode so system brightness takes effect immediately
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            val value = ((percent.coerceIn(5, 100) / 100f) * 255f).toInt().coerceIn(10, 255)
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                value
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    fun adjustBrightness(deltaPercent: Int): Pair<Boolean, Int> {
        val next = (getBrightnessPercent() + deltaPercent).coerceIn(5, 100)
        val ok = setBrightnessPercent(next)
        return ok to next
    }

    fun openWriteSettingsScreen() {
        val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    // endregion

    // region App Launchers

    fun openSystemSettings(): Boolean {
        return safeStartActivity(Intent(Settings.ACTION_SETTINGS))
    }

    fun openCamera(): Boolean {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        return safeStartActivity(intent)
    }

    fun openWhatsApp(): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
        return if (launchIntent != null) {
            safeStartActivity(launchIntent)
        } else {
            false
        }
    }

    private fun safeStartActivity(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    // endregion

    // region Haptics & Permissions

    fun vibrateTap(durationMs: Long = 22L) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator.vibrate(
                VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } catch (_: Exception) {
            // Ignore on devices without vibrator
        }
    }

    companion object {
        fun hasOverlayPermission(context: Context): Boolean {
            return Settings.canDrawOverlays(context)
        }

        fun hasAudioPermission(context: Context): Boolean {
            return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        }

        fun hasNotificationPermission(context: Context): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
            return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        }

        fun isAccessibilityServiceEnabled(context: Context): Boolean {
            val expectedComponent = ComponentName(context, DexDotAccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabledServices)
            while (splitter.hasNext()) {
                val componentName = ComponentName.unflattenFromString(splitter.next())
                if (componentName == expectedComponent) {
                    return true
                }
            }
            return false
        }
    }
    // endregion
}
