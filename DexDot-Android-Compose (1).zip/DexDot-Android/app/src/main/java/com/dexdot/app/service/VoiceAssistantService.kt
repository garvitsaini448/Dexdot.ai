package com.dexdot.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dexdot.app.ui.theme.DexAccentSky
import com.dexdot.app.ui.theme.DexBorder
import com.dexdot.app.ui.theme.DexDotTheme
import com.dexdot.app.ui.theme.DexSurface
import com.dexdot.app.ui.theme.DexSurfaceElevated
import com.dexdot.app.ui.theme.DexTextPrimary
import com.dexdot.app.ui.theme.DexTextSecondary
import com.dexdot.app.util.SystemControlHelper
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

data class AssistantUiState(
    val isListening: Boolean = false,
    val rmsLevel: Float = 0f,
    val transcript: String = "Listening...",
    val responseText: String = "Say \"volume up\", \"open camera\", or \"flashlight on\""
)

/**
 * Minimal voice assistant overlay powered by Android SpeechRecognizer.
 * Launched on double-tap of the floating dot or from the Quick-Menu.
 */
class VoiceAssistantService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var systemHelper: SystemControlHelper
    private lateinit var lifecycleOwner: OverlayLifecycleOwner

    private var overlayView: ComposeView? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val uiState = MutableStateFlow(AssistantUiState())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        systemHelper = SystemControlHelper(this)
        lifecycleOwner = OverlayLifecycleOwner().also { it.onCreate() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!SystemControlHelper.hasAudioPermission(this)) {
            Toast.makeText(
                this,
                "Grant Microphone permission in DexDot to use voice commands",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
            return START_NOT_STICKY
        }

        showOverlay()
        startListening()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        overlayView?.let {
            if (it.isAttachedToWindow) windowManager.removeView(it)
        }
        overlayView = null
        lifecycleOwner.onDestroy()
        super.onDestroy()
    }

    private fun showOverlay() {
        if (overlayView != null) return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = (28 * resources.displayMetrics.density).toInt()
        }

        val view = ComposeView(this).apply {
            lifecycleOwner.attachToView(this)
            setContent {
                val state by uiState.collectAsState()
                DexDotTheme {
                    VoiceAssistantBubble(
                        state = state,
                        onRetryMic = { startListening() },
                        onDismiss = { stopSelf() }
                    )
                }
            }
        }

        windowManager.addView(view, params)
        overlayView = view
    }

    private fun startListening() {
        mainHandler.removeCallbacksAndMessages(null)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            uiState.value = AssistantUiState(
                isListening = false,
                transcript = "Speech service unavailable",
                responseText = "Enable Google Speech Services on this device"
            )
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    uiState.value = AssistantUiState(
                        isListening = true,
                        transcript = "Listening...",
                        responseText = "Try: \"volume up\", \"mute\", \"open camera\", \"flashlight on\""
                    )
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    uiState.value = uiState.value.copy(rmsLevel = normalized)
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    uiState.value = uiState.value.copy(isListening = false)
                }

                override fun onError(error: Int) {
                    val reason = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap mic to try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                        else -> "Voice input stopped (code $error)."
                    }
                    uiState.value = uiState.value.copy(
                        isListening = false,
                        rmsLevel = 0f,
                        responseText = reason
                    )
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull().orEmpty()
                    if (spoken.isNotBlank()) {
                        handleCommand(spoken)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        uiState.value = uiState.value.copy(transcript = partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun handleCommand(rawText: String) {
        val cmd = rawText.lowercase(Locale.getDefault()).trim()
        val reply = when {
            "volume up" in cmd || "increase volume" in cmd || "louder" in cmd -> {
                val vol = systemHelper.increaseVolume()
                "Volume raised to $vol%"
            }
            "volume down" in cmd || "decrease volume" in cmd || "quieter" in cmd -> {
                val vol = systemHelper.decreaseVolume()
                "Volume lowered to $vol%"
            }
            "unmute" in cmd -> {
                systemHelper.setMuted(false)
                "Audio unmuted"
            }
            "mute" in cmd || "silent" in cmd -> {
                systemHelper.setMuted(true)
                "Audio muted"
            }
            "next" in cmd -> {
                systemHelper.nextTrack()
                "Skipped to next track"
            }
            "previous" in cmd || "prev" in cmd -> {
                systemHelper.previousTrack()
                "Returned to previous track"
            }
            "open settings" in cmd || "settings" in cmd -> {
                val ok = systemHelper.openSystemSettings()
                if (ok) "Opening Settings" else "Unable to open Settings"
            }
            "open camera" in cmd || "camera" in cmd -> {
                val ok = systemHelper.openCamera()
                if (ok) "Opening Camera" else "Camera app unavailable"
            }
            "open whatsapp" in cmd || "whatsapp" in cmd -> {
                val ok = systemHelper.openWhatsApp()
                if (ok) "Opening WhatsApp" else "WhatsApp is not installed"
            }
            "flashlight on" in cmd || "torch on" in cmd -> {
                val ok = systemHelper.setFlashlight(true)
                if (ok) "Flashlight turned on" else "Flashlight unavailable"
            }
            "flashlight off" in cmd || "torch off" in cmd -> {
                val ok = systemHelper.setFlashlight(false)
                if (ok) "Flashlight turned off" else "Flashlight unavailable"
            }
            "brightness up" in cmd || "brighter" in cmd -> {
                val (ok, pct) = systemHelper.adjustBrightness(+20)
                if (ok) "Brightness set to $pct%" else "Grant Modify System Settings for brightness"
            }
            "brightness down" in cmd || "dimmer" in cmd -> {
                val (ok, pct) = systemHelper.adjustBrightness(-20)
                if (ok) "Brightness set to $pct%" else "Grant Modify System Settings for brightness"
            }
            else -> "Unknown command: \"$rawText\""
        }

        uiState.value = uiState.value.copy(
            isListening = false,
            rmsLevel = 0f,
            transcript = "\"$rawText\"",
            responseText = reply
        )

        Toast.makeText(this, reply, Toast.LENGTH_SHORT).show()
        mainHandler.postDelayed({ stopSelf() }, 2400L)
    }

    companion object {
        const val ACTION_START_LISTENING = "com.dexdot.app.ACTION_START_LISTENING"
    }
}

@Composable
private fun VoiceAssistantBubble(
    state: AssistantUiState,
    onRetryMic: () -> Unit,
    onDismiss: () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "voice_orb")
    val pulse by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_scale"
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(24.dp),
        color = DexSurface,
        border = BorderStroke(1.dp, DexBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .scale(if (state.isListening) pulse + (state.rmsLevel * 0.15f) else 1f)
                            .clip(CircleShape)
                            .background(
                                if (state.isListening) DexAccentSky.copy(alpha = 0.22f)
                                else DexSurfaceElevated
                            )
                            .clickable(onClick = onRetryMic),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = "Voice input",
                            tint = if (state.isListening) DexAccentSky else DexTextSecondary
                        )
                    }

                    Spacer(Modifier.width(14.dp))

                    Column {
                        Text(
                            text = state.transcript,
                            color = DexTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = state.responseText,
                            color = DexTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Close assistant",
                        tint = DexTextSecondary
                    )
                }
            }

            if (state.isListening) {
                Spacer(Modifier.height(14.dp))
                VoiceWaveformBars(rmsLevel = state.rmsLevel)
            }
        }
    }
}

@Composable
private fun VoiceWaveformBars(rmsLevel: Float) {
    val barMultipliers = listOf(0.45f, 0.78f, 1.0f, 0.84f, 0.56f, 0.92f, 0.65f, 0.42f)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(22.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        barMultipliers.forEach { weight ->
            val barHeight = (6f + (16f * weight * (0.25f + rmsLevel * 0.75f))).dp
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(barHeight)
                    .clip(RoundedCornerShape(2.dp))
                    .background(DexAccentSky)
            )
        }
    }
}
