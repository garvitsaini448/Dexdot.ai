package com.dexdot.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.dexdot.app.data.DotConfig
import com.dexdot.app.data.DotCorner
import com.dexdot.app.data.DotPreferences
import com.dexdot.app.ui.theme.DexBgCanvas
import com.dexdot.app.ui.theme.DexBorder
import com.dexdot.app.ui.theme.DexDotTheme
import com.dexdot.app.ui.theme.DexSurface
import com.dexdot.app.ui.theme.DexSurfaceElevated
import com.dexdot.app.ui.theme.DexTextPrimary
import com.dexdot.app.ui.theme.DexTextSecondary
import kotlinx.coroutines.launch

private data class DotColorPreset(val name: String, val argb: Long)

private val ColorPresets = listOf(
    DotColorPreset("Sky", 0xFF38BDF8L),
    DotColorPreset("Emerald", 0xFF34D399L),
    DotColorPreset("Amber", 0xFFFBBF24L),
    DotColorPreset("Coral", 0xFFFB7185L),
    DotColorPreset("Violet", 0xFFA78BFAL),
    DotColorPreset("Chalk", 0xFFF8FAFCL)
)

private val SizePresetsDp = listOf(16, 20, 24, 32)

/**
 * Customization screen accessible from the long-press Quick-Menu -> Settings.
 * Updates DataStore preferences which immediately reflect in the running OverlayService.
 */
class SettingsActivity : ComponentActivity() {

    private lateinit var prefs: DotPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = DotPreferences(this)

        setContent {
            val config by prefs.configFlow.collectAsState(initial = DotConfig())

            DexDotTheme {
                SettingsScreen(
                    config = config,
                    onBack = { finish() },
                    onColorSelected = { argb ->
                        lifecycleScope.launch { prefs.setColor(argb) }
                    },
                    onSizeChanged = { dp ->
                        lifecycleScope.launch { prefs.setSizeDp(dp) }
                    },
                    onOpacityChanged = { alpha ->
                        lifecycleScope.launch { prefs.setOpacity(alpha) }
                    },
                    onCornerSelected = { corner ->
                        lifecycleScope.launch { prefs.setCorner(corner) }
                    },
                    onPulseChanged = { enabled ->
                        lifecycleScope.launch { prefs.setPulseEnabled(enabled) }
                    },
                    onHapticChanged = { enabled ->
                        lifecycleScope.launch { prefs.setHapticEnabled(enabled) }
                    },
                    onOpenAccessibility = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                )
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    config: DotConfig,
    onBack: () -> Unit,
    onColorSelected: (Long) -> Unit,
    onSizeChanged: (Int) -> Unit,
    onOpacityChanged: (Float) -> Unit,
    onCornerSelected: (DotCorner) -> Unit,
    onPulseChanged: (Boolean) -> Unit,
    onHapticChanged: (Boolean) -> Unit,
    onOpenAccessibility: () -> Unit
) {
    val activeColor = Color(config.colorArgb)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DexBgCanvas)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = DexTextPrimary
                )
            }
            Spacer(Modifier.width(4.dp))
            Text(
                text = "DexDot Settings",
                color = DexTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Live Dot Preview
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = DexSurface,
            border = BorderStroke(1.dp, DexBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Live Preview", color = DexTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "${config.sizeDp}dp · ${(config.opacity * 100).toInt()}% opacity · ${config.corner.label}",
                        color = DexTextSecondary,
                        fontSize = 12.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(DexBgCanvas),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(config.sizeDp.dp)
                            .alpha(config.opacity)
                            .clip(CircleShape)
                            .background(activeColor)
                            .border(1.5.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                    )
                }
            }
        }

        // Color Presets
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = DexSurface,
            border = BorderStroke(1.dp, DexBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("Dot Color", color = DexTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ColorPresets.forEach { preset ->
                        val selected = preset.argb == config.colorArgb
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(preset.argb))
                                .border(
                                    width = if (selected) 3.dp else 1.dp,
                                    color = if (selected) Color.White else DexBorder,
                                    shape = CircleShape
                                )
                                .clickable { onColorSelected(preset.argb) }
                        )
                    }
                }
            }
        }

        // Size & Opacity Sliders
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = DexSurface,
            border = BorderStroke(1.dp, DexBorder)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Dot Size", color = DexTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    val touchDp = maxOf(32, config.sizeDp + 8)
                    Text("${config.sizeDp} dp (${touchDp}dp touch)", color = DexTextSecondary, fontSize = 12.sp)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SizePresetsDp.forEach { sizeOption ->
                        val selected = config.sizeDp == sizeOption
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSizeChanged(sizeOption) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (selected) activeColor.copy(alpha = 0.16f) else DexSurfaceElevated,
                            border = BorderStroke(1.dp, if (selected) activeColor else DexBorder)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "${sizeOption}dp",
                                    color = if (selected) activeColor else DexTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Idle Opacity", color = DexTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("${(config.opacity * 100).toInt()}%", color = DexTextSecondary, fontSize = 13.sp)
                }
                Slider(
                    value = config.opacity,
                    onValueChange = onOpacityChanged,
                    valueRange = 0.35f..0.98f,
                    colors = SliderDefaults.colors(thumbColor = activeColor, activeTrackColor = activeColor)
                )
            }
        }

        // Default Corner Position
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = DexSurface,
            border = BorderStroke(1.dp, DexBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("Default Anchor Corner", color = DexTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Selecting a corner snaps the dot back from any custom drag offset.",
                    color = DexTextSecondary,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DotCorner.entries.chunked(2).forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowItems.forEach { corner ->
                                val selected = config.corner == corner && config.customX == -1
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { onCornerSelected(corner) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (selected) activeColor.copy(alpha = 0.16f) else DexSurfaceElevated,
                                    border = BorderStroke(1.dp, if (selected) activeColor else DexBorder)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = corner.label,
                                            color = if (selected) activeColor else DexTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Behavior Toggles
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = DexSurface,
            border = BorderStroke(1.dp, DexBorder)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Idle Glow Pulse", color = DexTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("Subtle breathing ring when dot is resting", color = DexTextSecondary, fontSize = 12.sp)
                    }
                    Switch(checked = config.pulseEnabled, onCheckedChange = onPulseChanged)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Haptic Feedback", color = DexTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("Short vibration on tap, swipe, and long-press", color = DexTextSecondary, fontSize = 12.sp)
                    }
                    Switch(checked = config.hapticEnabled, onCheckedChange = onHapticChanged)
                }
            }
        }

        OutlinedButton(
            onClick = onOpenAccessibility,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, DexBorder)
        ) {
            Text("Configure Accessibility Service", color = DexTextPrimary, fontSize = 13.sp)
        }
    }
}
