package com.dexdot.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DexBgCanvas = Color(0xFF0B0E14)
val DexSurface = Color(0xFF121721)
val DexSurfaceElevated = Color(0xFF19202E)
val DexBorder = Color(0xFF252E3F)
val DexAccentSky = Color(0xFF38BDF8)
val DexTextPrimary = Color(0xFFF1F5F9)
val DexTextSecondary = Color(0xFF94A3B8)
val DexSuccess = Color(0xFF34D399)
val DexWarning = Color(0xFFFBBF24)

private val DexDotColorScheme = darkColorScheme(
    primary = DexAccentSky,
    onPrimary = Color(0xFF06131F),
    secondary = DexSuccess,
    background = DexBgCanvas,
    onBackground = DexTextPrimary,
    surface = DexSurface,
    onSurface = DexTextPrimary,
    surfaceVariant = DexSurfaceElevated,
    onSurfaceVariant = DexTextSecondary,
    outline = DexBorder
)

@Composable
fun DexDotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DexDotColorScheme,
        content = content
    )
}
