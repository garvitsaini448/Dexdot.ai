package com.dexdot.app.ui.onboarding

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dexdot.app.ui.theme.DexAccentSky
import com.dexdot.app.ui.theme.DexBgCanvas
import com.dexdot.app.ui.theme.DexBorder
import com.dexdot.app.ui.theme.DexSuccess
import com.dexdot.app.ui.theme.DexSurface
import com.dexdot.app.ui.theme.DexSurfaceElevated
import com.dexdot.app.ui.theme.DexTextPrimary
import com.dexdot.app.ui.theme.DexTextSecondary

data class PermissionStatusState(
    val hasOverlay: Boolean,
    val hasAudio: Boolean,
    val hasAccessibility: Boolean
)

/**
 * Step-by-step onboarding screen explaining required and optional Android permissions
 * before starting the persistent DexDot overlay service.
 */
@Composable
fun OnboardingScreen(
    permissions: PermissionStatusState,
    onRequestOverlay: () -> Unit,
    onRequestAudio: () -> Unit,
    onRequestAccessibility: () -> Unit,
    onLaunchDexDot: () -> Unit
) {
    val canStart = permissions.hasOverlay

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DexBgCanvas)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Brand Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(DexAccentSky.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(DexAccentSky)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    text = "DexDot Setup",
                    color = DexTextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Grant access once so the floating dot works over every app",
                    color = DexTextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(Modifier.height(4.dp))

        PermissionCard(
            icon = Icons.Rounded.Layers,
            title = "Display over other apps",
            requirementLabel = "Required",
            description = "Allows DexDot to stay anchored in the corner of your screen above apps, videos, and games using Android WindowManager.",
            granted = permissions.hasOverlay,
            actionText = if (permissions.hasOverlay) "Granted" else "Allow Overlay",
            onAction = onRequestOverlay
        )

        PermissionCard(
            icon = Icons.Rounded.Mic,
            title = "Microphone access",
            requirementLabel = "Required for voice",
            description = "Powers the double-tap voice assistant using Android SpeechRecognizer for hands-free volume, camera, and torch commands.",
            granted = permissions.hasAudio,
            actionText = if (permissions.hasAudio) "Granted" else "Allow Microphone",
            onAction = onRequestAudio
        )

        PermissionCard(
            icon = Icons.Rounded.AccessibilityNew,
            title = "Accessibility service",
            requirementLabel = "Optional",
            description = "Unlocks advanced global navigation actions (Home, Back, Recents, and Quick Settings) on Android 10 and Android 11 devices without root.",
            granted = permissions.hasAccessibility,
            actionText = if (permissions.hasAccessibility) "Enabled" else "Open Accessibility",
            onAction = onRequestAccessibility
        )

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = onLaunchDexDot,
            enabled = canStart,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = DexAccentSky,
                contentColor = Color(0xFF06131F),
                disabledContainerColor = DexSurfaceElevated,
                disabledContentColor = DexTextSecondary
            )
        ) {
            Text(
                text = if (canStart) "Enable Floating DexDot" else "Allow Overlay to Continue",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun PermissionCard(
    icon: ImageVector,
    title: String,
    requirementLabel: String,
    description: String,
    granted: Boolean,
    actionText: String,
    onAction: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = DexSurface,
        border = BorderStroke(1.dp, if (granted) DexSuccess.copy(alpha = 0.45f) else DexBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (granted) DexSuccess else DexAccentSky,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = title,
                            color = DexTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = requirementLabel,
                            color = if (granted) DexSuccess else DexTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                if (granted) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = "Permission granted",
                        tint = DexSuccess,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            Text(
                text = description,
                color = DexTextSecondary,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )

            Spacer(Modifier.height(14.dp))

            OutlinedButton(
                onClick = onAction,
                enabled = !granted,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (granted) DexSuccess.copy(alpha = 0.4f) else DexBorder)
            ) {
                Text(
                    text = actionText,
                    color = if (granted) DexSuccess else DexTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
