package com.dexdot.app.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeMute
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FlashlightOff
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.dexdot.app.MainActivity
import com.dexdot.app.R
import com.dexdot.app.SettingsActivity
import com.dexdot.app.data.DotConfig
import com.dexdot.app.data.DotCorner
import com.dexdot.app.data.DotPreferences
import com.dexdot.app.ui.theme.DexBgCanvas
import com.dexdot.app.ui.theme.DexBorder
import com.dexdot.app.ui.theme.DexDotTheme
import com.dexdot.app.ui.theme.DexSurface
import com.dexdot.app.ui.theme.DexSurfaceElevated
import com.dexdot.app.ui.theme.DexTextPrimary
import com.dexdot.app.ui.theme.DexTextSecondary
import com.dexdot.app.util.SystemControlHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Foreground Service managing the persistent floating DexDot and its long-press Quick-Menu.
 * Uses WindowManager (TYPE_APPLICATION_OVERLAY) with GestureDetector + OnTouchListener
 * to handle dragging, directional swipes, single tap, double tap, and long press.
 */
class OverlayService : LifecycleService() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: DotPreferences
    private lateinit var systemHelper: SystemControlHelper
    private lateinit var lifecycleOwner: OverlayLifecycleOwner

    private var dotContainer: FrameLayout? = null
    private var dotParams: WindowManager.LayoutParams? = null
    private var quickMenuView: ComposeView? = null

    private val configState = MutableStateFlow(DotConfig())
    private var lastAppliedSizeDp = -1
    private var lastAppliedCorner: DotCorner? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = DotPreferences(this)
        systemHelper = SystemControlHelper(this)
        lifecycleOwner = OverlayLifecycleOwner().also { it.onCreate() }

        createNotificationChannel()
        startForegroundSafely()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        attachFloatingDot()

        lifecycleScope.launch {
            prefs.setServiceActive(true)
            prefs.configFlow.collect { config ->
                configState.value = config
                applyDotLayoutUpdates(config)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        dismissQuickMenu()
        dotContainer?.let {
            if (it.isAttachedToWindow) windowManager.removeView(it)
        }
        dotContainer = null
        lifecycleOwner.onDestroy()
        lifecycleScope.launch {
            prefs.setServiceActive(false)
        }
        super.onDestroy()
    }

    private fun startForegroundSafely() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.overlay_notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps the floating DexDot overlay responsive"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachFloatingDot() {
        val initialConfig = configState.value
        val touchPx = dpToPx(touchTargetDp(initialConfig.sizeDp))
        val (initX, initY) = resolveInitialPosition(initialConfig, touchPx)

        val params = WindowManager.LayoutParams(
            touchPx,
            touchPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX
            y = initY
        }
        dotParams = params

        val container = FrameLayout(this)
        val composeView = ComposeView(this).apply {
            lifecycleOwner.attachToView(this)
            setContent {
                val cfg by configState.collectAsState()
                DexDotTheme {
                    FloatingDotBubble(config = cfg)
                }
            }
        }
        container.addView(
            composeView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        val swipeVelocityThreshold = 550f
        var downRawX = 0f
        var downRawY = 0f
        var startWindowX = 0
        var startWindowY = 0
        var isDragging = false
        var gestureHandled = false

        val gestureDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    gestureHandled = true
                    triggerHaptic()
                    val muted = systemHelper.toggleMute()
                    showFeedback(if (muted) "Muted" else "Unmuted")
                    return true
                }

                override fun onDoubleTap(e: MotionEvent): Boolean {
                    gestureHandled = true
                    triggerHaptic(32L)
                    openVoiceAssistant()
                    return true
                }

                override fun onLongPress(e: MotionEvent) {
                    if (!isDragging) {
                        gestureHandled = true
                        triggerHaptic(38L)
                        showQuickMenu()
                    }
                }

                override fun onFling(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    velocityX: Float,
                    velocityY: Float
                ): Boolean {
                    val absX = abs(velocityX)
                    val absY = abs(velocityY)
                    if (absX < swipeVelocityThreshold && absY < swipeVelocityThreshold) {
                        return false
                    }

                    gestureHandled = true
                    // Restore dot to its pre-swipe resting position
                    params.x = startWindowX
                    params.y = startWindowY
                    windowManager.updateViewLayout(container, params)

                    triggerHaptic()
                    if (absY > absX) {
                        if (velocityY < 0) {
                            val vol = systemHelper.increaseVolume()
                            showFeedback("Volume $vol%")
                        } else {
                            val vol = systemHelper.decreaseVolume()
                            showFeedback("Volume $vol%")
                        }
                    } else {
                        if (velocityX < 0) {
                            systemHelper.previousTrack()
                            showFeedback("Previous Track")
                        } else {
                            systemHelper.nextTrack()
                            showFeedback("Next Track")
                        }
                    }
                    return true
                }
            }
        )

        container.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWindowX = params.x
                    startWindowY = params.y
                    isDragging = false
                    gestureHandled = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        val metrics = resources.displayMetrics
                        params.x = (startWindowX + dx).coerceIn(0, metrics.widthPixels - params.width)
                        params.y = (startWindowY + dy).coerceIn(0, metrics.heightPixels - params.height)
                        windowManager.updateViewLayout(container, params)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isDragging && !gestureHandled) {
                        lifecycleScope.launch {
                            prefs.setCustomPosition(params.x, params.y)
                        }
                    }
                    isDragging = false
                    true
                }

                else -> false
            }
        }

        windowManager.addView(container, params)
        dotContainer = container
        lastAppliedSizeDp = initialConfig.sizeDp
        lastAppliedCorner = initialConfig.corner
    }

    private fun applyDotLayoutUpdates(config: DotConfig) {
        val container = dotContainer ?: return
        val params = dotParams ?: return
        var dirty = false

        if (config.sizeDp != lastAppliedSizeDp) {
            val newPx = dpToPx(touchTargetDp(config.sizeDp))
            params.width = newPx
            params.height = newPx
            lastAppliedSizeDp = config.sizeDp
            dirty = true
        }

        if (config.customX == -1 && config.customY == -1 && config.corner != lastAppliedCorner) {
            val (cx, cy) = resolveInitialPosition(config, params.width)
            params.x = cx
            params.y = cy
            lastAppliedCorner = config.corner
            dirty = true
        }

        if (dirty && container.isAttachedToWindow) {
            windowManager.updateViewLayout(container, params)
        }
    }

    private fun resolveInitialPosition(config: DotConfig, windowPx: Int): Pair<Int, Int> {
        if (config.customX >= 0 && config.customY >= 0) {
            return config.customX to config.customY
        }
        val metrics = resources.displayMetrics
        val marginPx = dpToPx(10)
        val topMarginPx = dpToPx(36)
        val bottomMarginPx = dpToPx(28)

        return when (config.corner) {
            DotCorner.BOTTOM_RIGHT ->
                (metrics.widthPixels - windowPx - marginPx) to (metrics.heightPixels - windowPx - bottomMarginPx)
            DotCorner.BOTTOM_LEFT ->
                marginPx to (metrics.heightPixels - windowPx - bottomMarginPx)
            DotCorner.TOP_RIGHT ->
                (metrics.widthPixels - windowPx - marginPx) to topMarginPx
            DotCorner.TOP_LEFT ->
                marginPx to topMarginPx
        }
    }

    private fun showQuickMenu() {
        if (quickMenuView != null) return

        val menuParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        val view = ComposeView(this).apply {
            lifecycleOwner.attachToView(this)
            setContent {
                val cfg by configState.collectAsState()
                DexDotTheme {
                    QuickMenuOverlay(
                        accentColor = Color(cfg.colorArgb),
                        initialVolume = systemHelper.getVolumePercent(),
                        initialBrightness = systemHelper.getBrightnessPercent(),
                        initialTorchOn = systemHelper.isTorchOn,
                        canWriteSettings = systemHelper.canWriteSystemSettings(),
                        onVolumeChange = { systemHelper.setVolumePercent(it) },
                        onBrightnessChange = {
                            if (!systemHelper.setBrightnessPercent(it)) {
                                systemHelper.openWriteSettingsScreen()
                                dismissQuickMenu()
                            }
                        },
                        onToggleFlashlight = {
                            val ok = systemHelper.toggleFlashlight()
                            if (!ok) showFeedback("Flashlight unavailable")
                            systemHelper.isTorchOn
                        },
                        onOpenAssistant = {
                            dismissQuickMenu()
                            openVoiceAssistant()
                        },
                        onOpenSettings = {
                            dismissQuickMenu()
                            val intent = Intent(this@OverlayService, SettingsActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                        },
                        onDismiss = { dismissQuickMenu() }
                    )
                }
            }
        }

        windowManager.addView(view, menuParams)
        quickMenuView = view
    }

    private fun dismissQuickMenu() {
        quickMenuView?.let {
            if (it.isAttachedToWindow) {
                windowManager.removeView(it)
            }
        }
        quickMenuView = null
    }

    private fun openVoiceAssistant() {
        val intent = Intent(this, VoiceAssistantService::class.java).apply {
            action = VoiceAssistantService.ACTION_START_LISTENING
        }
        startService(intent)
    }

    private fun triggerHaptic(durationMs: Long = 20L) {
        if (configState.value.hapticEnabled) {
            systemHelper.vibrateTap(durationMs)
        }
    }

    private fun showFeedback(message: String) {
        Toast.makeText(this, "DexDot: $message", Toast.LENGTH_SHORT).show()
    }

    private fun touchTargetDp(sizeDp: Int): Int {
        // Keep touch hitbox >= 32dp even when visual dot is 16dp, 20dp, or 24dp
        return maxOf(32, sizeDp + 8)
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    companion object {
        private const val CHANNEL_ID = "dexdot_overlay_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.dexdot.app.ACTION_STOP_OVERLAY"
    }
}

@Composable
private fun FloatingDotBubble(config: DotConfig) {
    val accent = Color(config.colorArgb)
    val transition = rememberInfiniteTransition(label = "dexdot_pulse")
    val pulseScale by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    val pulseAlpha by transition.animateFloat(
        initialValue = 0.16f,
        targetValue = 0.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (config.pulseEnabled) {
            Box(
                modifier = Modifier
                    .size(config.sizeDp.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = pulseAlpha))
            )
        }

        Box(
            modifier = Modifier
                .size(config.sizeDp.dp)
                .alpha(config.opacity)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            accent.copy(alpha = 0.90f),
                            accent.copy(alpha = 0.65f)
                        )
                    )
                )
                .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size((config.sizeDp * 0.24f).dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.75f))
            )
        }
    }
}

@Composable
private fun QuickMenuOverlay(
    accentColor: Color,
    initialVolume: Int,
    initialBrightness: Int,
    initialTorchOn: Boolean,
    canWriteSettings: Boolean,
    onVolumeChange: (Int) -> Unit,
    onBrightnessChange: (Int) -> Unit,
    onToggleFlashlight: () -> Boolean,
    onOpenAssistant: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    var volume by remember { mutableFloatStateOf(initialVolume.toFloat()) }
    var brightness by remember { mutableFloatStateOf(initialBrightness.toFloat()) }
    var torchOn by remember { mutableStateOf(initialTorchOn) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .width(308.dp)
                .clickable(enabled = false) {},
            shape = RoundedCornerShape(24.dp),
            color = DexSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DexBorder)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DexDot Quick Menu",
                        color = DexTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close quick menu",
                            tint = DexTextSecondary
                        )
                    }
                }

                // Volume Control
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (volume <= 0f) Icons.AutoMirrored.Rounded.VolumeMute else Icons.AutoMirrored.Rounded.VolumeUp,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Volume", color = DexTextPrimary, fontSize = 13.sp)
                        }
                        Text("${volume.toInt()}%", color = DexTextSecondary, fontSize = 12.sp)
                    }
                    Slider(
                        value = volume,
                        onValueChange = {
                            volume = it
                            onVolumeChange(it.toInt())
                        },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = accentColor,
                            activeTrackColor = accentColor
                        )
                    )
                }

                // Brightness Control
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Brightness6,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Brightness", color = DexTextPrimary, fontSize = 13.sp)
                        }
                        Text(
                            text = if (canWriteSettings) "${brightness.toInt()}%" else "Grant access",
                            color = DexTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Slider(
                        value = brightness,
                        onValueChange = {
                            brightness = it
                            onBrightnessChange(it.toInt())
                        },
                        valueRange = 5f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = accentColor,
                            activeTrackColor = accentColor
                        )
                    )
                }

                // Action Tiles: Flashlight, Assistant, Settings
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = if (torchOn) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff,
                        label = if (torchOn) "Torch On" else "Torch Off",
                        active = torchOn,
                        accentColor = accentColor,
                        onClick = { torchOn = onToggleFlashlight() }
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Mic,
                        label = "Assistant",
                        active = false,
                        accentColor = accentColor,
                        onClick = onOpenAssistant
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Settings,
                        label = "Settings",
                        active = false,
                        accentColor = accentColor,
                        onClick = onOpenSettings
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickActionButton(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(68.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (active) accentColor.copy(alpha = 0.16f) else DexSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (active) accentColor else DexBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) accentColor else DexTextPrimary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = label,
                color = if (active) accentColor else DexTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}
