# Keep Jetpack Compose & DataStore classes intact
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
